package com.kh.jsp.notice.model.exception;

public class NoticeException extends Exception {
	
	public NoticeException () {
		super();
	}
	
	public NoticeException(String msg) {
		super(msg);
	}

}
