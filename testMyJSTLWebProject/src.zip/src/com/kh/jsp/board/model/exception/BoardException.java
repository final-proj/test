package com.kh.jsp.board.model.exception;

public class BoardException extends Exception {

	public BoardException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BoardException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}
	
	

}
